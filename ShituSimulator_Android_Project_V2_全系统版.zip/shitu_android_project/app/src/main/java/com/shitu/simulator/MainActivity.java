package com.shitu.simulator;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.Context;

public class MainActivity extends Activity {
    private WebView webView;
    private android.content.SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("shitu_save", Context.MODE_PRIVATE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GameBridge(), "AndroidGame");
        webView.loadUrl("file:///android_asset/game.html");
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("(document.getElementById('eventModal')?.classList.contains('active')?'modal':(UI&&UI.view!=='overview'?'view':'none'))", value -> {
            if ("\"modal\"".equals(value)) webView.evaluateJavascript("hideEventModal()", null);
            else if ("\"view\"".equals(value)) webView.evaluateJavascript("UI.view='overview';renderAll()", null);
            else super.onBackPressed();
        });
    }

    public class GameBridge {
        @JavascriptInterface public void save(String json) {
            prefs.edit().putString("game", json).apply();
        }
        @JavascriptInterface public String load() { return prefs.getString("game", ""); }
        @JavascriptInterface public void clearSave() { prefs.edit().remove("game").apply(); }
        @JavascriptInterface public void toast(String msg) { runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show()); }
    }
}
