# 《仕途·公务员晋升模拟器》Android V2.0

这是一个离线 Android WebView 游戏工程。游戏本体位于 `app/src/main/assets/game.html`。

## 本版主要系统

- 季度制推进、精力、工作任务与自然恢复
- 政绩、民主测评、学历、组织考察综合晋升
- 具体职务链与行政级别分离
- 干部档案、推荐任用、干部梯队培养
- 常委会博弈、关键人物关系、逐人投票
- 政治生态：务实派/改革派/发展派/稳健派/中间派
- 跨派系政策联盟与联盟重组
- 上级关键人物与组织综合评价
- 政策路线：发展、民生、改革、风险防控
- 重大项目、财政、债务、就业、住房、医疗、教育、环境、稳定
- 自然灾害、悲痛事故、温暖故事、真能量、舆情等事件
- 个人现金、合法公司、房产与廉政风险
- 纪委监委调查、利益冲突申报与整改
- 全国党代会与中央身份
- 生涯成就与终局
- Android 离线自动存档

> 游戏人物、派系、事件和政治博弈均为架空的游戏化机制，不代表现实人物或现实政治程序。

## 构建 APK

### GitHub Actions（推荐）

1. 解压整个工程。
2. 新建 GitHub 仓库并上传 `shitu_android_project` 文件夹中的全部内容。
3. 打开仓库的 **Actions**。
4. 选择 **Build Android APK**。
5. 点击 **Run workflow**。
6. 构建完成后进入对应任务，在 **Artifacts** 下载 `shitu-apk-v2`。

### Android Studio

用 Android Studio 打开工程根目录，执行：

`Build → Build APK(s)`

输出文件：

`app/build/outputs/apk/debug/app-debug.apk`
